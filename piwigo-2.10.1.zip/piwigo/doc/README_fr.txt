=======
Piwigo
=======

Site web:        http://fr.piwigo.org
Installation:    http://fr.piwigo.org/basics/installation
Mise � jour:     http://fr.piwigo.org/basics/upgrade

Prendre un bon d�part
=====================

Une fois install�e ou mise � jour, votre galerie est pr�te �
fonctionner. Commencez par vous rendre sur le r�pertoire d'installation dans
votre navigateur : 

http://votre.domaine/photos

Ensuite, identifiez-vous en tant qu'un administrateur. Un nouveau lien dans
le menu d'identification de la page principale va appara�tre :
Administration. Suivre ce lien :-)

Dans la zone d'administration, prenez tout le temps n�cessaire pour
consulter les instructions, expliquant comment utiliser votre galerie.

Communication
=============

Newsletter
----------

http://fr.piwigo.org/basics/newsletter

Il est *fortement* recommand� de souscrire � la newsletter de
Piwigo. Tr�s peu de mails sont envoy�s, mais les informations sont
importantes : nouvelles versions de l'application, notification de bugs
importants (relatifs � la s�curit�).

Freshmeat
---------

http://freecode.com/projects/piwigo

Permet d'�tre au courant des sorties de toutes les releases, et en
exclusivit� les builds de la branche de d�veloppement (ce qui n'est pas
pr�vu sur les mailing lists "announce").

Outil de suivi de bogues
------------------------

http://piwigo.org/bugs

Gestion des bugs, mais aussi demande de nouvelles fonctionnalit�s. Rien de
plus efficace pour qu'un bug soit corrig� : tant qu'il ne l'est pas, la
"fiche" reste l� � attendre, on ne l'oublie pas comme un topic sur le
forum.

Les demandes d'�volutions sont �galement g�r�es dans cet outil. Ce n'est pas
forc�ment id�al car il ne s'agit pas de la m�me chose, mais le suivi du dev
d'une nouvelle fonctionnalit� peut se mod�liser de la m�me fa�on que le
suivi de la correction d'un bug.

Documentation
-------------

http://fr.piwigo.org/doc

Forum de discussion
-------------------

http://fr.piwigo.org/forum

Un forum est disponible et recommand� pour toutes les questions autres que
les demandes d'�volution et rapport de bogue (installation, discussions
techniques).
